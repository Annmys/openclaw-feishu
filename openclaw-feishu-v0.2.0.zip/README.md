# OpenClaw Feishu 中央权限版 🤖

基于 [clawdbot-feishu](https://github.com/m1heng/clawdbot-feishu) 优化的飞书插件，增加了**中央权限管理**和**主控监控**功能。

适合需要**多用户权限管控**、**任务汇报**、**敏感操作审批**的企业场景。

> 📖 **[安装指南](INSTALL.md)** | 📝 **[身份表示例](examples/feishu-identity.yaml)**

---

## ✨ 核心特性

### 1. 四层权限体系 (L1/L2/L3/L0)

| 层级 | 角色 | 权限范围 |
|:----:|:----:|:---------|
| **L1** | 大A | 全局管理、所有操作、规则修改 |
| **L2** | 部门负责人 | 本部门规则修改、审批L3任务 |
| **L3** | 部门员工 | 查询、提交任务、本部门文件读取 |
| **L0** | 未授权 | 仅查询，任何操作需L1确认 |

### 2. 动态Agent + 主控监控

```
飞书用户 (Bella/L3)
    │
    ▼
飞书插件路由
    │
    ├──→ 独立Agent (日常任务)
    │      └── 权限受限
    │      └── 完成后汇报主控
    │
    └──→ 主控Agent (敏感操作)
           └── 审批权限请求
           └── 统一发群汇报
```

### 3. 身份自动识别

- **已登记用户**：自动识别，立即响应
- **ID变更**：同一人换账号，自动继承权限
- **新人登记**：发送「我是XXX」，提交大A确认
- **冒充检测**：声称他人身份，标记可疑

### 4. 智能用户识别 👤

**自动获取飞书用户姓名**，告别 `ou_xxxxx`：

| 场景 | 显示方式 |
|:-----|:---------|
| 已登记用户 | 显示身份表中的姓名（如"Bella"）|
| 新用户 | 调用飞书API获取真实姓名 |
| 未知用户 | 显示短格式ID（如`ou_0826...905b`）|

**优势：**
- ✅ 大A看到的是"Bella请求权限"而不是"ou_5cd4..."
- ✅ 任务汇报显示真实姓名
- ✅ 10分钟缓存，避免频繁调用API

### 5. 任务汇报铁律

| 任务来源 | 汇报方式 |
|:---------|:---------|
| **L1（大A）** | 不输出到群 |
| **L2/L3/L0** | 完成后必须发群汇报 |

**汇报格式（三行）：**
```
✅[姓名] [成功]
📝 任务简述
📎 输出文件:文件路径或无
```

---

## 🚀 快速开始

### 1. 安装插件

```bash
# 从npm安装（推荐）
openclaw plugins install @Annmys/openclaw-feishu

# 或从GitHub安装
openclaw plugins install https://github.com/Annmys/openclaw-feishu.git
```

### 2. 配置身份映射表

在工作空间创建 `rules/feishu-identity.yaml`：

```yaml
verified_users:
  # 大A - 最高权限
  ou_xxxxxxxxxxxxxxxx:
    name: "大A"
    level: "L1"
    department: "全局"
    verified_at: "2025-02-05T19:00:00+08:00"
    status: "active"
    
  # Bella - 采购部门负责人
  ou_yyyyyyyyyyyyyyyy:
    name: "Bella"
    level: "L2"
    department: "采购"
    verified_at: "2025-02-05T19:00:00+08:00"
    status: "active"
    
  # aa1 - 采购部门员工
  ou_zzzzzzzzzzzzzzzz:
    name: "aa1"
    level: "L3"
    department: "采购"
    verified_at: "2025-02-05T19:00:00+08:00"
    status: "active"

channels:
  feishu_groups:
    oc_report_group_id:
      name: "任务汇报群"
      type: "group"
```

### 3. 配置插件

```bash
openclaw config set channels.feishu.appId "cli_xxxxx"
openclaw config set channels.feishu.appSecret "your_secret"
openclaw config set channels.feishu.enabled true

# 启用动态Agent创建
openclaw config set channels.feishu.dynamicAgentCreation.enabled true
openclaw config set channels.feishu.dynamicAgentCreation.workspaceTemplate "~/workspaces/feishu-{agentId}"

# 配置主控会话Key
openclaw config set channels.feishu.centralAuth.masterSessionKey "agent:main:main"
```

---

## ⚙️ 配置选项

### 中央权限配置

```yaml
channels:
  feishu:
    enabled: true
    appId: "cli_xxxxx"
    appSecret: "secret"
    
    # 权限策略
    dmPolicy: "allowlist"           # 私聊白名单
    groupPolicy: "allowlist"        # 群聊白名单
    requireMention: true            # 群聊需@机器人
    
    # 动态Agent创建
    dynamicAgentCreation:
      enabled: true
      workspaceTemplate: "~/workspaces/feishu-{agentId}"
      agentDirTemplate: "~/.openclaw/agents/{agentId}/agent"
      maxAgents: 100
    
    # 中央权限配置
    centralAuth:
      # 主控会话Key
      masterSessionKey: "agent:main:main"
      # 身份映射表路径（默认：~/.openclaw/workspace/rules/feishu-identity.yaml）
      identityMapPath: ""
      # 汇报群ID
      reportGroupId: "oc_xxxxxxxxxx"
      # 是否启用自动身份确认
      enableAutoConfirm: true
```

### 会话隔离配置

```yaml
session:
  # 私聊会话隔离
  dmScope: "per-peer"
```

---

## 🛡️ 权限矩阵

| 操作类型 | L1 | L2 | L3 | L0 |
|:---------|:--:|:--:|:--:|:--:|
| 查询/搜索 | ✅ | ✅ | ✅ | ✅ |
| 读取文件 | ✅ | ✅ | 本部门✅ | ❌ |
| 修改文件 | ✅ | 本部门✅ | ❌ | ❌ |
| Git操作 | ✅ | ❌ | ❌ | ❌ |
| Docker操作 | ✅ | ❌ | ❌ | ❌ |
| 系统命令 | ✅ | ❌ | ❌ | ❌ |
| 发送消息 | ✅ | 需确认 | ❌ | ❌ |
| 修改规则 | ✅ | 本部门✅ | ❌ | ❌ |

---

## 🔄 工作流程

### 新人入群流程

```
新员工私聊机器人
    │
    ▼
发送「我是XXX」
    │
    ▼
检查身份映射表
    │
    ├── 名字已存在（非L1）──→ ✅ 自动确认，继承权限
    │
    ├── 全新人 ──────────────→ 📝 提交主控，等待大A确认
    │
    └── 声称是L1 ────────────→ 🚫 标记可疑，人工审核
```

### 敏感操作流程

```
L3用户请求敏感操作（如Git）
    │
    ▼
权限检查 ──→ 权限不足
    │
    ▼
回复：「此操作需要最高权限，已为您提交到大A确认」
    │
    ▼
转发到主控Agent
    │
    ▼
大A审批 ──→ 授权/拒绝
    │
    ▼
返回结果给用户
```

### 任务汇报流程

```
Bella完成任务
    │
    ▼
独立Agent处理
    │
    ▼
发送 sessions_send 到主控
    │
    ▼
主控Agent接收汇报
    │
    ▼
发送到汇报群（三行格式）
```

---

## 📁 文件结构

```
openclaw-feishu/
├── src/
│   ├── channel.ts          # 飞书通道主逻辑
│   ├── dynamic-agent.ts    # 动态Agent创建
│   ├── central-auth.ts     # 中央权限管理器 ⭐
│   ├── identity.ts         # 身份验证模块 ⭐
│   ├── gatekeeper.ts       # 权限检查模块 ⭐
│   ├── reporter.ts         # 任务汇报模块 ⭐
│   ├── bot.ts              # 飞书Bot封装
│   ├── runtime.ts          # 运行时工具
│   └── ...                 # 其他工具模块
├── skills/                 # 飞书相关技能
├── index.ts                # 插件入口
├── package.json
└── README.md
```

---

## 🆚 与原版的区别

| 特性 | 原版 | 中央权限版 |
|:-----|:----:|:----------:|
| 动态Agent创建 | ✅ | ✅ |
| 身份验证 | ❌ | ✅ |
| 权限矩阵 | ❌ | ✅ |
| 敏感操作审批 | ❌ | ✅ |
| 任务汇报 | ❌ | ✅ |
| 主控监控 | ❌ | ✅ |
| 自动身份确认 | ❌ | ✅ |

---

## 🔧 原项目功能

本插件完整保留原项目的所有功能：

- ✅ WebSocket/Webhook 连接模式
- ✅ 私聊和群聊
- ✅ 消息回复和引用上下文
- ✅ 入站媒体支持（图片、文件）
- ✅ 文档工具（feishu_doc）
- ✅ 知识库工具（feishu_wiki）
- ✅ 云空间工具（feishu_drive）
- ✅ 多维表格工具（feishu_bitable）
- ✅ @转发功能
- ✅ 权限错误提示

详见原项目文档：[clawdbot-feishu](https://github.com/m1heng/clawdbot-feishu)

---

## 📝 使用示例

### 身份登记

```
【用户】我是小李
【机器人】您好！我是小A 🤖

您的身份尚未登记，请等待大A确认后使用。

如 urgent，请直接联系大A。

[同时转发到主控]
```

### 敏感操作

```
【Bella】帮我git push一下
【机器人】此操作需要最高权限，已为您提交到大A确认，请稍候...

[转发到主控]
🚨 权限请求
来源: 飞书私聊
请求人: Bella (L2)
详情: 请求操作: git

[✅ 授权执行] [❌ 拒绝]
```

### 任务汇报

```
【群消息】
✅[aa1] [成功]
📝 整理采购订单
📎 输出文件:/data/gongxiang/aa1/订单.xlsx
```

---

## 🤝 感谢

- 基于 [m1heng/clawdbot-feishu](https://github.com/m1heng/clawdbot-feishu) 开发
- 遵循 MIT 许可证

---

*维护者：小A 🤖*  
*版本：0.2.0*
